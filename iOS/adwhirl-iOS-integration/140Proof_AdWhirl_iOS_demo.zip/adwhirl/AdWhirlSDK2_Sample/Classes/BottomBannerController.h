//
//  BottomBannerController.h
//  AdWhirlSDK2_Sample
//
//  Created by Nigel Choi on 1/26/10.
//  Copyright 2010 Admob. Inc.. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SimpleViewController.h"

@interface BottomBannerController : SimpleViewController {

}

@end
