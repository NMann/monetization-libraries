//
//  ModalViewController.h
//  AdWhirlSDK2_Sample
//
//  Created by Nigel Choi on 3/11/10.
//  Copyright 2010 Admob. Inc. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ModalViewController : UIViewController {

}

- (IBAction)dismiss:(id)sender;

@end
